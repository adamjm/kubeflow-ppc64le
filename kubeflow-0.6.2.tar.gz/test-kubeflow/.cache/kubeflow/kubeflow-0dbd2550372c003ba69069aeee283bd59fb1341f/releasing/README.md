# Scripts for managing releases

See instructions [here](https://github.com/kubeflow/kubeflow/blob/master/docs_dev/releasing.md)
