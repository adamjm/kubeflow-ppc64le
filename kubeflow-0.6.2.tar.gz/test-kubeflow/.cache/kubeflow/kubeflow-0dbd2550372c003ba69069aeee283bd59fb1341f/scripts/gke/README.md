This directory contains scripts specific to GKE/GCP.
