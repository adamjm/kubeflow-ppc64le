This ksonnet app contains some manifests to be used in the E2E test.
