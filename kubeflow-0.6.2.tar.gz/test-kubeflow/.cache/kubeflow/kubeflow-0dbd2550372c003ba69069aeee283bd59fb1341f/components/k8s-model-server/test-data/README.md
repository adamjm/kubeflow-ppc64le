<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->
**Table of Contents**  *generated with [DocToc](https://github.com/thlorenz/doctoc)*

- [Test data for the TF serving component.](#test-data-for-the-tf-serving-component)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

# Test data for the TF serving component.

mnist_input.json can be used to test the mnist model at gs://kubeflow-ci-test-models/mnist with http-proxy.
