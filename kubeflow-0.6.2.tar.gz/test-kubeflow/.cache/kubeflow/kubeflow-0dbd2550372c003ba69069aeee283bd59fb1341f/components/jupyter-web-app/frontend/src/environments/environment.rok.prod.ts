export const environment = {
  production: true,
  apiUrl: "/jupyter",
  resource: "notebooks",
  ui: "rok",
  rokUrl: ""
};
